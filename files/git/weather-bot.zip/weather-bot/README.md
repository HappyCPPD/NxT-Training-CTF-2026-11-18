# weather-bot
a discord bot that tells you the weather
