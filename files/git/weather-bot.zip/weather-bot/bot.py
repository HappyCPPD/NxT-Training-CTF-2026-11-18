import os
import requests

API_KEY = os.environ["API_KEY"]  # safe now :)

def weather(city):
    return requests.get(URL, params={"key": API_KEY, "q": city})
